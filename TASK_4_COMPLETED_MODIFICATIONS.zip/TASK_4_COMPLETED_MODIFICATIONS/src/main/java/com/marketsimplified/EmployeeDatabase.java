package com.marketsimplified;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.json.*;
import javax.servlet.http.HttpServletResponse;
import javax.script.ScriptContext;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.http.HttpResponse;
import java.sql.*;
import java.util.Properties;

public class EmployeeDatabase
{
    private static Connection conn;
    private static   PreparedStatement insertEmployeeStmt1;
    private static PreparedStatement insertEmployeeStmt2;
    private static PreparedStatement insertEmployeeStmt3;
    private static PreparedStatement updateEmployeeStmt1;
    private static PreparedStatement updateEmployeeStmt2;
    private static PreparedStatement updateEmployeeStmt3;
    private static PreparedStatement deleteEmployeeStmt1;
    private static PreparedStatement deleteEmployeeStmt2;
    private static PreparedStatement deleteEmployeeStmt3;
    private static PreparedStatement searchEmployeeStmt1;
    private static PreparedStatement searchEmployeeStmt2;
    private static PreparedStatement searchEmployeeStmt3;


Logger logger = (Logger) LogManager.getLogger(EmployeeDatabase.class);
static Properties props = new Properties();




    public  EmployeeDatabase() throws SQLException
    {

        //try(FileInputStream fis = new FileInputStream("config.properties")){
//            props.load(fis);
//            String dbUrl = props.getProperty("db.url");
//            String dbUsername = props.getProperty("db.username");
//            String dbPassword = props.getProperty("db.password");
            //conn =  DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
    	   try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	    conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "Samudralashanmuk123#");
            insertEmployeeStmt1 = conn.prepareStatement("INSERT INTO PermanentEmployee (name, age, salary, bonus) VALUES (?, ?, ?, ?)",Statement.RETURN_GENERATED_KEYS);
            insertEmployeeStmt2 = conn.prepareStatement("INSERT INTO ContractEmployee (name, age, salary, contractPeriod) VALUES (?, ?, ?, ?)");
            insertEmployeeStmt3 = conn.prepareStatement("INSERT INTO PartTimeEmployee (name, age, salary, hoursWorked) VALUES (?, ?, ?, ?)");
            updateEmployeeStmt1 = conn.prepareStatement("UPDATE PermanentEmployee SET name = ?, age = ?, salary = ?, bonus = ? WHERE id = ?");
            updateEmployeeStmt2 = conn.prepareStatement("UPDATE ContractEmployee SET name = ?, age = ?, salary = ?, contractPeriod = ? WHERE id = ?");
            updateEmployeeStmt3 = conn.prepareStatement("UPDATE PartTimeEmployee SET name = ?, age = ?, salary = ?, hoursWorked = ? WHERE id = ?");
            deleteEmployeeStmt1 = conn.prepareStatement("DELETE FROM PermanentEmployee WHERE id = ?");
            deleteEmployeeStmt2 = conn.prepareStatement("DELETE FROM ContractEmployee WHERE id = ?");
            deleteEmployeeStmt3 = conn.prepareStatement("DELETE FROM PartTimeEmployee WHERE id = ?");
            searchEmployeeStmt1 = conn.prepareStatement("SELECT id, name, age, salary, bonus from PermanentEmployee WHERE id = ?");
            searchEmployeeStmt2 = conn.prepareStatement("SELECT id, name, age, salary, bonus from ContractEmployee WHERE id = ?");
            searchEmployeeStmt3 = conn.prepareStatement("SELECT id, name, age, salary, bonus from PartTimeEmployee WHERE id = ?");
       // } catch (IOException e) {
            //throw new RuntimeException(e);
       // }
    }
    public void addEmployee(PermanentEmployee permanentEmployee) throws SQLException
    {
        try
        {
            insertEmployeeStmt1.setString(1, permanentEmployee.getName());
            insertEmployeeStmt1.setInt(2, permanentEmployee.getAge());
            insertEmployeeStmt1.setInt(3, permanentEmployee.getSalary());
            insertEmployeeStmt1.setInt(4, permanentEmployee.getBonus());
            insertEmployeeStmt1.executeUpdate();
            logger.info("Employee added");
            ResultSet generatedKeys = insertEmployeeStmt1.getGeneratedKeys();
            if (generatedKeys.next()) {
                int generatedId = generatedKeys.getInt(1);
                System.out.println("Generated ID: " + generatedId);
            }
        }
        catch (Exception e)
        {
            logger.info("Duplicate id found");
        }
        finally {

            conn.close();
            insertEmployeeStmt1.close();
        }

    }
    public void addEmployee(ContractEmployee contractEmployee) throws SQLException
    {
        try
        {
    insertEmployeeStmt2.setString(1, contractEmployee.getName());
    insertEmployeeStmt2.setInt(2, contractEmployee.getAge());
    insertEmployeeStmt2.setInt(3, contractEmployee.getSalary());
    insertEmployeeStmt2.setInt(4, contractEmployee.getContractPeriod());
    insertEmployeeStmt2.executeUpdate();
    logger.info("Employee added");
}
catch (Exception e){
    logger.info(e);
}
finally {
    conn.close();
    insertEmployeeStmt2.close();
}
    }
    public void addEmployee(PartTimeEmployee partTimeEmployee) throws SQLException
    {
         try {
             insertEmployeeStmt3.setString(1, partTimeEmployee.getName());
             insertEmployeeStmt3.setInt(2, partTimeEmployee.getAge());
             insertEmployeeStmt3.setInt(3, partTimeEmployee.getSalary());
             insertEmployeeStmt3.setInt(4, partTimeEmployee.getHoursWorked());
             insertEmployeeStmt3.executeUpdate();
             logger.info("Employee added");
         }
    catch(Exception e){
            logger.info(e);
    }
finally {
        conn.close();
        insertEmployeeStmt2.close();
    }
         }

    public void updateEmployee(PermanentEmployee permanentEmployee,int id) throws SQLException {
        try
        {
        updateEmployeeStmt1.setString(1, permanentEmployee.getName());
        updateEmployeeStmt1.setInt(2, permanentEmployee.getAge());
        updateEmployeeStmt1.setInt(3, permanentEmployee.getSalary());
        updateEmployeeStmt1.setInt(4, permanentEmployee.getBonus());
        updateEmployeeStmt1.setInt(5, id);
        int result = updateEmployeeStmt1.executeUpdate();
        if (result > 0) {
            logger.info("Employee updated");
        } else {
            logger.info("Employe not found");
        }
    }
        finally {
            conn.close();
            updateEmployeeStmt1.close();
        }
    }
    public void updateEmployee(ContractEmployee contractEmployee,int id) throws SQLException
    {
        try
        {
        updateEmployeeStmt2.setString(1, contractEmployee.getName());
        updateEmployeeStmt2.setInt(2, contractEmployee.getAge());
        updateEmployeeStmt2.setInt(3, contractEmployee.getSalary());
        updateEmployeeStmt2.setInt(4, contractEmployee.getContractPeriod());
        updateEmployeeStmt2.setInt(5, id);
        int result = updateEmployeeStmt2.executeUpdate();
        if (result > 0)
        {
            logger.info("Employee updated");
        } else {
            logger.info("Employe not found");
        }
    }
    finally
        {
        conn.close();
        updateEmployeeStmt2.close();
    }
    }
    public void updateEmployee(PartTimeEmployee partTimeEmployee,int id) throws SQLException
    {try {
        updateEmployeeStmt3.setString(1, partTimeEmployee.getName());
        updateEmployeeStmt3.setInt(2, partTimeEmployee.getAge());
        updateEmployeeStmt3.setInt(3, partTimeEmployee.getSalary());
        updateEmployeeStmt3.setInt(4, partTimeEmployee.getHoursWorked());
        updateEmployeeStmt3.setInt(5, id);
        int result = updateEmployeeStmt3.executeUpdate();
        if (result > 0) {
            logger.info("Employee updated");
        } else {
            logger.info("Employe not found");
        }
    }
    finally {
        conn.close();
        updateEmployeeStmt3.close();
    }
    }
    public void deleteEmployee1(int id) throws SQLException {
        try {
            deleteEmployeeStmt1.setInt(1, id);
            int result = deleteEmployeeStmt1.executeUpdate();
            if(result>0){
                logger.info("Employee deleted");
            }
            else {
                logger.warn("Employee id not found");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            deleteEmployeeStmt1.close();
            conn.close();
        }
    }
    public void deleteEmployee2(int id) throws SQLException {
        try {
            deleteEmployeeStmt2.setInt(1, id);
            int result = deleteEmployeeStmt2.executeUpdate();
            if(result>0){
                logger.info("Employee deleted");
            }
            else {
                logger.warn("Employee id not found");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            deleteEmployeeStmt2.close();
            conn.close();
        }
    }
    public void deleteEmployee3(int id) throws SQLException
    {
        try
        {
        deleteEmployeeStmt3.setInt(1, id);
        int result = deleteEmployeeStmt3.executeUpdate();
            if(result>0){
                logger.info("Employee deleted");
            }
            else {
                logger.warn("Employee id not found");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally {
            deleteEmployeeStmt3.close();
            conn.close();

        }
    }

    public void permanentJson() throws SQLException
    {//conn =  DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
        ResultSet resultSet = null;
        try
        {
            String SELECT_EMPLOYEES_QUERY = "SELECT id, name, age, salary, bonus FROM PermanentEmployee";
            Statement statement = conn.createStatement();
            resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
            JSONArray jsonArray = new JSONArray();
            while (resultSet.next())
            {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", resultSet.getInt("id"));
                jsonObject.put("name", resultSet.getString("name"));
                jsonObject.put("age", resultSet.getInt("age"));
                jsonObject.put("salary", resultSet.getInt("salary"));
                jsonObject.put("bonus", resultSet.getInt("bonus"));
                jsonArray.put(jsonObject);
            }
            System.out.println(jsonArray);
        }
        finally {
            if(resultSet!=null)
            {
                resultSet.close();
            }
            conn.close();
        }
    }

    public void partTimeJson() throws SQLException
    {
        conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "Samudralashanmuk123#");
        ResultSet resultSet = null;
        try{
        String SELECT_EMPLOYEES_QUERY = "SELECT id, name, age, salary, hoursWorked  FROM PartTimeEmployee";
        Statement statement = conn.createStatement();
       resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
        JSONArray jsonArray = new JSONArray();
        while (resultSet.next()) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", resultSet.getInt("id"));
            jsonObject.put("name", resultSet.getString("name"));
            jsonObject.put("age", resultSet.getInt("age"));
            jsonObject.put("salary", resultSet.getInt("salary"));
            jsonObject.put("hoursWorked",resultSet.getInt("hoursWorked"));
            jsonArray.put(jsonObject);
        }
        System.out.println(jsonArray);
    }
        finally {
            if(resultSet!=null)
            {
                resultSet.close();
            }
    conn.close();
              }
    }
    public void contractJson() throws SQLException
    {
        conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "Samudralashanmuk123#");
        ResultSet resultSet = null;
        try{
        String SELECT_EMPLOYEES_QUERY = "SELECT id, name, age, salary, contractPeriod  FROM ContractEmployee";
        Statement statement = conn.createStatement();
         resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
        JSONArray jsonArray = new JSONArray();
        while (resultSet.next())
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", resultSet.getInt("id"));
            jsonObject.put("name", resultSet.getString("name"));
            jsonObject.put("age", resultSet.getInt("age"));
            jsonObject.put("salary", resultSet.getInt("salary"));
            jsonObject.put("contractPeriod",resultSet.getInt("contractPeriod"));
            jsonArray.put(jsonObject);
        }
        System.out.println(jsonArray);
         }
        finally
        {
            if(resultSet!=null)
            {
                resultSet.close();
            }
            conn.close();
        }
    }
    
    public  String searchRecord(int id,int empno) throws SQLException, ClassNotFoundException
    { 
    	
    	     String jsonData = "1";
             conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "Samudralashanmuk123#");
             ResultSet resultSet1 = null;
             ResultSet resultSet2 = null;
             ResultSet resultSet3 = null;
             if(empno==1) 
             {
            	 searchEmployeeStmt1 = conn.prepareStatement("SELECT id, name, age, salary, bonus from PermanentEmployee WHERE id = ?");
                 searchEmployeeStmt1.setInt(1, id);
                 resultSet1 = searchEmployeeStmt1.executeQuery();
                 JSONArray jsonArray = new JSONArray();
                 while (resultSet1.next())
                 {
                 JSONObject jsonObject = new JSONObject();
                 jsonObject.put("empId", resultSet1.getInt("id"));
                 jsonObject.put("name", resultSet1.getString("name"));
                 jsonObject.put("age", resultSet1.getInt("age"));
                 jsonObject.put("salary", resultSet1.getInt("salary"));
                 jsonObject.put("bonus", resultSet1.getInt("bonus"));
                 jsonArray.put(jsonObject);
                 jsonData = jsonArray.toString();
                 } 
             }
             else if(empno==2) 
             {
            	 searchEmployeeStmt2 = conn.prepareStatement("SELECT id, name, age, salary, contractPeriod from ContractEmployee WHERE id = ?");
                 searchEmployeeStmt2.setInt(1, id);
                 resultSet2 = searchEmployeeStmt2.executeQuery();
                 JSONArray jsonArray = new JSONArray();
                 while (resultSet2.next())
                 {
                 JSONObject jsonObject = new JSONObject();
                 jsonObject.put("empId", resultSet2.getInt("id"));
                 jsonObject.put("name", resultSet2.getString("name"));
                 jsonObject.put("age", resultSet2.getInt("age"));
                 jsonObject.put("salary", resultSet2.getInt("salary"));
                 jsonObject.put("contractPeriod", resultSet2.getInt("contractPeriod"));
                 jsonArray.put(jsonObject);
                 jsonData = jsonArray.toString();
                 } 
             }
             else if(empno==3) 
             {
            	 searchEmployeeStmt3 = conn.prepareStatement("SELECT id, name, age, salary, hoursWorked from PartTimeEmployee WHERE id = ?");
                 searchEmployeeStmt3.setInt(1, id);
                 resultSet3 = searchEmployeeStmt3.executeQuery();
                 JSONArray jsonArray = new JSONArray();
                 while (resultSet3.next())
                 {
                 JSONObject jsonObject = new JSONObject();
                 jsonObject.put("empId", resultSet3.getInt("id"));
                 jsonObject.put("name", resultSet3.getString("name"));
                 jsonObject.put("age", resultSet3.getInt("age"));
                 jsonObject.put("salary", resultSet3.getInt("salary"));
                 jsonObject.put("hoursWorked", resultSet3.getInt("hoursWorked"));
                 jsonArray.put(jsonObject);
                 jsonData = jsonArray.toString();
                 } 
             }
             
		return jsonData;
    }
}
